Chargement des données dans Google Colab:
================================================

Avant de charger le TP, pour utiliser le GPU:
Edit -> Notebook settings --> GPU


Etape 1: Copier le répertoire "TP_ConvNet" dézippé dans votre espace sur Google Drive
Etape 2: Charger le notebook puis monter Google Drive dans Colab:

from google.colab import drive
drive.mount("/content/gdrive/")


Etape 3: Une fois google Drive monté, placez-vous dans le répertoire du TP:

cd gdrive/MyDrive/TP_ConvNet



