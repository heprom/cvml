"""
Load pairs of image and target from the dataset, and define
transformations on the images (random crop, histogram distortion,
horizontal flip)
"""

import torch
import skimage.transform as tr
from skimage import img_as_float
import os
from skimage import io
from skimage.color import label2rgb, rgb2hsv, hsv2rgb, grey2rgb, rgb2gray
import numpy as np


# -------------------------------------------------
# 1: Some tools
# -------------------------------------------------

def rand_scale(s):

    """
    Return a random scale

    :param s: Scale parameter
    :type s: float
    """

    scale = np.random.uniform(1, s)
    if(np.random.randint(1, 10000) % 2): 
        return scale
    return 1./scale


# -------------------------------------------------
# 2: Dataset management
# -------------------------------------------------

class SegmentationDataset:

    """
    Class handling the segmentation dataset
    """

    def __init__(self, root_dir, input_dir, target_dir, transform = None):

        """
        Class constructor

        :param root_dir: Root directory 
        :type root_dir: String
        :param input_dir: Path to the training images
        :type input_dir: String
        :param target_dir: Path to the training targets
        :type target_dir: String
        :param transform: Transformations to apply to the images
        :type transform: Python list
        """

        self.root_dir = root_dir
        self.input_dir = input_dir
        self.target_dir = target_dir
        self.transform = transform
        self.images = os.listdir(os.path.join(self.root_dir, self.input_dir))


    def __len__(self):

        """
        Return the number of images in the dataset

        :return: Number of images in the dataset
        :rtype: int
        """

        return len(self.images)


    def __getitem__(self, idx):

        """
        Return an image of the dataset along with the corresponding
        target image

        :param idx: Index of the image in the dataset
        :type idx: int

        :return: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img_name = os.path.join(self.root_dir,
          self.input_dir,
          self.images[idx])

        target_name = os.path.join(self.root_dir,
          self.target_dir,
          str("binary_") + self.images[idx][:-4] + '.npy')
          
        target_gauss_name = os.path.join(self.root_dir,
          self.target_dir,
          str("gaussian_") + self.images[idx][:-4] + '.png')

        img =  grey2rgb(io.imread(img_name))
        target = np.load(target_name, allow_pickle=True)
        target_gauss = io.imread(target_gauss_name)
        
        sample = {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': self.images[idx][:-4]}

        if self.transform:
            sample = self.transform(sample)

        return sample


# -------------------------------------------------
# 3: Data augmentation methods
# -------------------------------------------------

class Crop(object):

    """
    Crop images from a sample

    Args:

    output_size (tuple or int): Desired output size. If int, a square crop
    is extracted.

    """

    def __init__(self, output_size, upperleft = (0,0)):

        """
        Constructor

        :param output_size: Desired output size. If int, a square crop
         is extracted.
        :type output_size: int
        """

        assert isinstance(output_size, (int, tuple))
        if isinstance(output_size, int):
            self.output_size = (output_size, output_size)

        else:
            assert len(output_size) == 2
            self.output_size = output_size

        self.top = upperleft[1]
        self.left = upperleft[0]


    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """
        
        
        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']

        h, w = img.shape[:2]
        new_h, new_w = self.output_size

        img = img[self.top:self.top+new_h, self.left:self.left+new_w]
        target = target[self.top:self.top+new_h, self.left:self.left+new_w]
        target_gauss = target_gauss[self.top:self.top+new_h, self.left:self.left+new_w]
        
        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}



class RandomCrop(object):

    """
    Randomly crop images from a sample.

    Args:

    output_size (tuple or int): Desired output size. If int, a square crop
    is extracted.
    """

    def __init__(self, output_size):

        """
        Constructor

        :param output_size: Desired output size. If int, a square crop
         is extracted.
        :type output_size: int
        """

        assert isinstance(output_size, (int, tuple))
        if isinstance(output_size, int):
            self.output_size = (output_size, output_size)
        else:
            assert len(output_size) == 2
            self.output_size = output_size


    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']

        h, w = img.shape[:2]
        new_h, new_w = self.output_size
        
        rand = np.random.uniform(0.3,2.0)
        rand_h, rand_w = int(rand*new_h), int(rand*new_w)
        
        top = np.random.randint(0, h - rand_h)
        left = np.random.randint(0, w - rand_w)

        img = tr.resize(img[top:top + rand_h,left:left + rand_w], (new_h, new_w), anti_aliasing=True)
        target = tr.resize(target[top:top + rand_h,left:left + rand_w], (new_h, new_w), anti_aliasing=False,order=0)
        target_gauss = tr.resize(target_gauss[top:top + rand_h,left:left + rand_w], (new_h, new_w), anti_aliasing=True)

        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}


class Flip(object):

    """
    Flip the image horizontally
    """

    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        
        flip = np.random.randint(0, 2) 

        if(flip):
            img = np.flip(img,axis=1).copy()
            target = np.flip(target,axis=1).copy()
            target_gauss = np.flip(target_gauss,axis=1).copy()

        """
        Notes on np.flip:
        Current version of torch.from_numpy() does not support
        negative ndarray striding. A -not so elegant- solution
        to this problem, is to make a copy of the ndarray, during which
        process, the negative strides are removed.
        """

        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}  


class Rotate(object):

    """
    Rotates the image by 
	
	.. math::
	n \times 90°
	
	where n is a random integer in [0,3].
    To be used only with square crops, or if batch_size==1
    """

    def __call__(self, sample):

        """
        
        
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        
        angle = np.random.randint(0, 4) 

        if(angle==1):
            img = tr.rotate(img,90)
            target = tr.rotate(target,90)
            target_gauss = tr.rotate(target_gauss,90)
        elif(angle==2):
            img = tr.rotate(img,180)
            target = tr.rotate(target,180)
            target_gauss = tr.rotate(target_gauss,180)
        elif(angle==3):
            img = tr.rotate(img,270)
            target = tr.rotate(target,270)
            target_gauss = tr.rotate(target_gauss,270)
        else:
            pass
            
        
        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}  


class Distort(object):

    """
    Distort the image histogram
    """

    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        img_hsv = rgb2hsv(img)

        hue = np.random.uniform(-0.1, 0.1)
        saturation = rand_scale(0.5)
        exposure = rand_scale(0.5)

        img_hsv[:, :, 1] *= saturation
        img_hsv[:, :, 2] *= exposure

        img_hsv[:, :, 0] += 255*hue
        img_hsv[(img_hsv[:, :, 0]>255), 0] -= 255 
        img_hsv[(img_hsv[:, :, 0]<0), 0] += 255  

        img = hsv2rgb(img_hsv)      

        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}


class SetTarget(object):

    """
    Construct the target image from the labels
    """

    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        target = np.stack((target,target_gauss),axis=2) #make a 2 channel target image (binary+gaussian)

        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}


class Normalize(object):

    """
    Normalizes images from a sample between 0 and 1
    """

    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        img = img_as_float(img)
        target = img_as_float(target)
        target_gauss = img_as_float(target_gauss)
        
        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}


class ToTensor(object):

    """
    Converts the ndarrays from the samples into PyTorch Tensors
    """

    def __call__(self, sample):

        """
        Apply the transform to the specified sample

        :param sample: Dictionary containing the input image (key: "input")
         and the target image (key: "target")
        :type sample: Dictionary

        :return: Dictionary containing the transformed input image (key: "input")
         and the target image (key: "target")
        :rtype: Dictionary
        """

        img, target, target_gauss, name = sample['input'], sample['target'], sample['target_gauss'], sample['name']
        
        img = img.transpose((2, 1, 0))
        target = target.transpose((2, 1, 0))

        img = torch.from_numpy(img).float()
        target = torch.from_numpy(target).float()

        return {'input': img, 'target': target, 'target_gauss': target_gauss, 'name': name}


